# ROMA - بناء APK من الموبايل فقط

هذا المشروع يحتوي على Workflow جاهز لـ GitHub Actions.

الخطوات:
1. أنشئ Repository جديد على GitHub باسم ROMA.
2. ارفع كل ملفات المشروع إلى الـ Repository، بما فيها مجلد `.github`.
3. افتح تبويب Actions.
4. اختر `Build ROMA APK` ثم `Run workflow` إذا لم يبدأ البناء تلقائياً.
5. بعد نجاح البناء افتح صفحة الـ workflow run وانزل إلى Artifacts.
6. حمّل `ROMA-debug-apk` وفك الضغط عن الملف ثم ثبّت `app-debug.apk` على هاتفك.

البناء هنا Debug APK للتجربة، وليس نسخة Play Store موقعة بمفتاح نشر خاص.
